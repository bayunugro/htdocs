<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Selamat Datang</title>
  <!--  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/default.css"> -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.css">
  </head>
  <body>
    <!-- multistep form -->
    <div class="container">
      <div class="py-5 text-center">
        <img class="d-block mx-auto mb-4" src="<?php echo base_url();?>/assets/img/balitbang.jpg" alt="" width="100" height="100"></img>
        <h2>Buku Tamu</h2>
        <p class="lead">Perpustakaan Badan Litbang Perhubungan</p>
      </div>
    </div>
    <div class="container">
      <div class="row justify-content-lg-center ">
        <fieldset>

        <form class="">
          <div class="form-group row justify-content-lg-center">
            <label for="namaLengkap" class="col-sm-5 col-form-label">Nama Lengkap</label>
            <div class="col-sm-7">
              <input type="text" class="form-control" id="nmLengkap" placeholder="masukan nama lengkap">
            </div>
          </div>
          <div class="form-group row">
            <label for="jenisKelamin" class="col-sm-5 col-form-label">Jenis kelamin</label>
            <div class="col-sm-7">
              <div class="form-check">
                <label class="form-check-label">
                  <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
                  Pria
                </label>
              </div>
              <div class="form-check">
                <label class="form-check-label">
                  <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
                  Perempuan &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
              </div>

            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword3" class="col-sm-5 col-form-label">Alamat</label>
            <div class="col-sm-7">
            <textarea name="name" rows="5" cols="50"></textarea>
            </div>
          </div>
          <div class="form-group row justify-content-lg-center">
            <label for="Instansi" class="col-sm-5 col-form-label">Instansi </label>
            <div class="col-sm-7">
              <input type="text" class="form-control" id="nmLengkap" placeholder="">
            </div>
          </div>
          <div class="form-group row justify-content-lg-center">
            <label for="Instansi" class="col-sm-5 col-form-label">Pekerjaan</label>
            <div class="col-sm-7">
              <input type="text" class="form-control" id="nmLengkap" placeholder="">
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword3" class="col-sm-5 col-form-label">Keperluan</label>
            <div class="col-sm-7">
            <textarea name="name" rows="5" cols="50"></textarea>
            </div>
          </div>
          <div class="form-group row">
            <div class="offset-sm-5  col-sm-10">
              <button type="submit" class="btn btn-primary">Register</button>
            </div>
          </div>
        </form>
      </div>
      </div>
    <script src="<?php echo base_url();?>/assets/js/default.js"></script>
  </body>
</html>
