    <div class="col-lg-12 text-center" style="padding:5px;"><small>&copy; 2017 by <a target="_blank" href="http://rudiliu.com">Rudi Liu</a></small></div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->

    <script src="<?=base_url()?>assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?=base_url()?>assets/js/jquery-ui-1.11.4.custom/jquery-ui.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?=base_url()?>assets/js/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?=base_url()?>assets/js/jquery.dataTables.min.js"></script>
    <script src="<?=base_url()?>assets/js/dataTables.bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/js/bootstrap-editable.min.js"></script>
    <script src="<?=base_url()?>assets/js/bootstrap-editable.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?=base_url()?>assets/js/sb-admin-2.js"></script>

    



</body>

</html>