 <?php 
 $header = '<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
        <td align="center">
 <tbody><tr style="padding:0;vertical-align:top;text-align:left">
      <td align="center" valign="top" style="word-break:break-word;padding:0;vertical-align:top;text-align:left;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;border-collapse:collapse!important">
        <center style="width:100%;min-width:580px">
        

          <table style="border-spacing:0;border-collapse:collapse;padding:0px;vertical-align:top;text-align:left;width:100%">
            <tbody><tr style="padding:0;vertical-align:top;text-align:left">
              <td align="center" style="word-break:break-word;padding:0;vertical-align:top;text-align:left;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;border-collapse:collapse!important">
                <center style="width:100%;min-width:580px">

                  <table style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:inherit;width:580px;margin:0 auto">
                    <tbody><tr style="padding:0;vertical-align:top;text-align:left">
                      <td style="word-break:break-word;padding:0;vertical-align:top;text-align:left;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;padding-right:0px;border-collapse:collapse!important">

                        <table style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;margin:0 auto;width:540px">
                          <tbody><tr style="padding:0;vertical-align:top;text-align:left">
                            <td style="word-break:break-word;padding:0px 0px 10px;vertical-align:top;text-align:left;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;border-collapse:collapse!important">
                              <div style="text-align:left">
                              </div>
                            </td>
                            <td style="word-break:break-word;padding:0!important;vertical-align:top;text-align:left;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;width:0px;border-collapse:collapse!important"></td>
                          </tr>
                        </tbody></table>

                      </td>
                    </tr>
                  </tbody></table>

                </center>
              </td>
            </tr>
          </tbody></table>

          <table style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:inherit;width:580px;margin:0 auto">
            <tbody><tr style="padding:0;vertical-align:top;text-align:left">
              <td style="word-break:break-word;padding:0;vertical-align:top;text-align:left;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;border-collapse:collapse!important">

                <table style="border-spacing:0;border-collapse:collapse;padding:0px;vertical-align:top;text-align:left;width:100%;display:block">
                  <tbody><tr style="padding:0;vertical-align:top;text-align:left">
                    <td style="word-break:break-word;padding:0;vertical-align:top;text-align:left;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;padding-right:0px;border-collapse:collapse!important">

                      <div style="background:#ffffff;background-color:#ffffff;border:1px solid #dddddd;padding:20px;border-radius:3px">

                        <table style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;margin:0 auto;width:540px">
                          <tbody><tr style="padding:0;vertical-align:top;text-align:left">
                            <td style="word-break:break-word;padding:0px 0px 10px;vertical-align:top;text-align:left;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;border-collapse:collapse!important">

                              <div>';


 $footer = '</div>

                            </td>
                            <td style="word-break:break-word;padding:0!important;vertical-align:top;text-align:center;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;width:0px;border-collapse:collapse!important"></td>
                          </tr>
                        </tbody></table>

                      </div>

                    </td>
                  </tr>
                </tbody></table>

              </td>
            </tr>
          </tbody></table>

          <table style="border-spacing:0;border-collapse:collapse;padding:0px;vertical-align:top;text-align:center;width:100%">
            <tbody><tr style="padding:0;vertical-align:top;text-align:center">
              <td align="center" style="word-break:break-word;padding:0;vertical-align:top;text-align:center;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;border-collapse:collapse!important">
                <center style="width:100%;min-width:580px">

                  <table style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:inherit;width:580px;margin:0 auto">
                    <tbody><tr style="padding:0;vertical-align:top;text-align:center">
                      <td style="word-break:break-word;padding:0;vertical-align:top;text-align:center;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;padding-right:0px;border-collapse:collapse!important">

                        <table style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:center;margin:0 auto;width:540px">
                          <tbody><tr style="padding:0;vertical-align:top;text-align:center">
                            <td style="word-break:break-word;padding:0px 0px 10px;vertical-align:top;text-align:center;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;border-collapse:collapse!important">
                              <div style="margin:0 0 15px 0"><br>
                              </div>
                              <div style="margin:0 0 15px 0">
                                <p style="margin:0;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-size:12px;font-weight:normal;color:#999;line-height:20px;padding:0;text-align:center"> &copy; 2017 <a href="www.rudiliu.com">Rudi Liu</></p>
                               
                              </div>
                            </td>
                            <td style="word-break:break-word;padding:0!important;vertical-align:top;text-align:center;color:#333333;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin:0;line-height:20px;font-size:14px;width:0px;border-collapse:collapse!important"></td>
                          </tr>
                        </tbody></table>

                      </td>
                    </tr>
                  </tbody></table>

                </center>
              </td>
            </tr>
          </tbody></table>

        
        </center>
      </td>
    </tr>
  </tbody></td></tr></table>';
  ?>